# JogoDoMilhao
Criação de um jogo de perguntas e respostas que concede uma pontuação final, desenvolvido em React e node
